<?php
/**
* courses short summary.
*
* courses description.
* Class courses with all variable has in courses table.
* Getter and Setter to all the variable.
*/

class courses{
    public $id_course;
    public $course_name;
    public $course_status;

    public function __construct(){

    }

    /* Getter & Setter */
    public function getIdCourse()
    {
        return $this->id_course;
    }
    public function setIdCourse($id_course)
    {
        $this->id_course=$id_course;
    }

    public function getCourseName()
    {
        return $this->course_name;
    }
    public function setCourseName($course_name)
    {
        $this->course_name=$course_name;
    }

    public function getCourseStatus()
    {
        return $this->course_status;
    }
    public function setCourseStatus($course_status)
    {
        $this->course_status=$course_status;
    }
}
?>