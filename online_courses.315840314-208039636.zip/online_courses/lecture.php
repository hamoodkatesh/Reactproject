<?php
/**
* lecture short summary.
*
* lecture description.
* Class lecture with all variable has in lecture table.
* Getter and Setter to all the variable.
*/

class lecture{
    public $id_lecture;
    public $id_course;
    public $name;
    public $discrption;
    public $lecture_status;

    public function __construct(){

    }

    /* Getter & Setter */
    public function getIdLecture()
    {
        return $this->id_lecture;
    }
    public function setIdLecture($id_lecture)
    {
        $this->id_lecture=$id_lecture;
    }

    public function getIdCourse()
    {
        return $this->id_course;
    }
    public function setIdCourse($id_course)
    {
        $this->id_course=$id_course;
    }

    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name=$name;
    }

    public function getDiscrption()
    {
        return $this->discrption;
    }
    public function setDiscrption($discrption)
    {
        $this->discrption=$discrption;
    }

    public function getCourseStatus()
    {
        return $this->lecture_status;
    }
    public function setLectureStatus($lecture_status)
    {
        $this->lecture_status=$lecture_status;
    }
}
?>