<?php
/* Includes */
require_once "courses.php";
require_once "lecture.php";

class DBConnection
{
    private $host;
    private $db;
    private $charset;
    private $user;
    private $pass;
    private $opt=array(
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
    );
private $connection;


/**************************** Conection to server ****************************/
    public function __construct(string $host="localhost",string $db="online_course",string $charset="utf8", string
    $user="root", string $pass="")
    {
        $this->host=$host;
        $this->db=$db;
        $this->charset=$charset;
        $this->user=$user;
        $this->pass=$pass;
    }

    /**************************** Conection to database Start****************************/
    private function connect()
    {
        $dsn="mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
        try{
            $this->connection = new PDO($dsn,$this->user,$this->pass,$this->opt);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int)$e->getCode());
        }
    }
    public function disconnect()
    {
    $this->connection = null;
    }

    /** Getting all Courses **/
    public function getAllCoures()
    {
        $this->connect();
        $data = $this->connection->query('SELECT * FROM courses ORDER BY course_name ASC;');
        $this->disconnect();
        return $data;
    }

    public function getAllLecture($id_get)
    {
        $this->connect();
        $data = $this->connection->prepare('SELECT courses.id_course, lecture.id_lecture, lecture.name, lecture.discrption, lecture.lecture_status FROM lecture JOIN courses ON courses.id_course = lecture.id_course WHERE courses.id_course LIKE ?;');
        $data->execute([$id_get]);
        $this->disconnect();
        return $data;
    }

    public function getLectureDisc($id_course)
    {
        $this->connect();
        $data = $this->connection->prepare('SELECT `name`, `discrption`, `lecture_status` FROM `lecture` WHERE `id_lecture` LIKE ?;');
        $data->execute([$id_course]);
        $this->disconnect();
        return $data;
    }

    public function updateLecutreStatus($id_lec)
    {
        $this->connect();
        $sql = "UPDATE `lecture` SET `lecture_status` = !`lecture_status` WHERE `id_lecture` LIKE $id_lec;";;
        $data= $this->connection->exec($sql);
        $this->disconnect();
        return $data;
    }

    public function findCourse($id_lec)
    {
        $this->connect();
        $data = $this->connection->prepare('SELECT courses.id_course FROM lecture JOIN courses ON courses.id_course = lecture.id_course WHERE lecture.id_lecture LIKE ?;');
        $data->execute([$id_lec]);
        $this->disconnect();
        return $data;
    }

    public function doneCourse($id_course)
    {
        $this->connect();
        $data = $this->connection->prepare('SELECT * FROM `lecture` WHERE id_course = ? and lecture_status = 0;');
        $data->execute([$id_course]);
        $this->disconnect();
        return $data->rowCount();
    }

    public function updateCourse($id_course, $value)
    {
        $this->connect();
        $sql = "UPDATE `courses` SET `course_status` = $value WHERE `id_course` LIKE $id_course;";;
        $data= $this->connection->exec($sql);
        $this->disconnect();
        return $data;
    }

}
?>