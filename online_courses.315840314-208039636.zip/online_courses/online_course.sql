-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2021 at 01:29 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_course`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id_course` int(11) NOT NULL,
  `course_name` varchar(265) COLLATE utf8_unicode_ci NOT NULL,
  `course_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id_course`, `course_name`, `course_status`) VALUES
(1, 'Java', 1),
(2, 'PHP', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE `lecture` (
  `id_lecture` int(77) NOT NULL,
  `id_course` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `discrption` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `lecture_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`id_lecture`, `id_course`, `name`, `discrption`, `lecture_status`) VALUES
(1, 1, 'Types and Variables', 'Primitive data types - includes byte, short, int, long, float, double, boolean and char. Non-primitive data types - such as String, Arrays and Classes', 1),
(2, 1, 'Methods', 'A method is a block of code which only runs when it is called. You can pass data, known as parameters, into a method. Methods are used to perform certain actions, and they are also known as functions.', 1),
(3, 2, 'Variables in PHP', 'In PHP, a variable starts with the $ sign, followed by the name of the variable', 0),
(4, 2, 'Arrays', 'An array is a special variable, which can hold more than one value at a time.', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
