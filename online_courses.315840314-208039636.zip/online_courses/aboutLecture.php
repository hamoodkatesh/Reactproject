<?php
    require_once "DBConnection.php";
    require_once "courses.php";
    require_once "lecture.php";

    $db = new DBConnection();// מסוג משתנהDBConnection

    $id_lec=$_GET['id_lec'];

    $res1 = $db->findCourse($id_lec);
    while($row1 = $res1->fetch(PDO::FETCH_ASSOC)):
    {
        $id_course=$row1['id_course'];
    }
    endwhile;

    if(isset($_POST['update'])) {
        $user_id = $_GET['id_lec'];
        $db->updateLecutreStatus($id_lec);
        if($db->doneCourse($id_course) == 0)
            {
                $db->updateCourse($id_course, 1);
                header("location:index.php");
            }else
            {
                $db->updateCourse($id_course, 0);
                header("location:lecturePage.php?id_course=$id_course");
            }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Table V01</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
</head>

<body>
    <div class="limiter">
        <div class="container-table100">
            <div class="wrap-table100">
                <div class="table100">
<h1>About Lecture</h1>
    <h2>Click on update botton if you understand the lecture</h2>
                    <table>
                        <thead>
                        <?php $res = $db->getLectureDisc($id_lec);?>
                        <?php while($row = $res->fetch(PDO::FETCH_ASSOC)):
                                    {
                                        $name=$row['name'];
                                        $discrption=$row['discrption'];
                                        $status=$row['lecture_status'];
                                        $bg_color = 'palegreen';
                                        if($status == 0)
                                            $bg_color = 'white';
                            }?>
                            <tr class="table100-head">
                                <th class="column1"><?php echo $name;?></th>
                                <th class="column2">Update</th>
                            </tr>
                        </thead>
                       
                        <tbody>
                        <tr style="background-color: <?php echo $bg_color ?>">
                                <td class="column1"><?php echo $discrption;?></button></a></td>
                                <form method="post">
                                    <td class="column2"><input type="submit" name="update" value="update" class=" btn btn-primary"></td>
                                </form>              
                            </tr>
                        </tbody>
                        <?php endwhile;?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--===============================================================================================-->
    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="js/main.js"></script>

</body>
</html>